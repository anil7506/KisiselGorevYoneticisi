using Microsoft.AspNetCore.Mvc;
using KisiselGorevYoneticisi.Models;
using System.Collections.Generic;

namespace KisiselGorevYoneticisi.Controllers
{
    public class TaskController : Controller
    {
        // Ekranda gösterilecek geçici görev listesi
        private static List<TaskItem> gorevListesi = new List<TaskItem>()
        {
            new TaskItem { Id = 1, GorevAdi = "Programlama II projesini tamamla", Durum = true },
            new TaskItem { Id = 2, GorevAdi = "Proje kodlarını mail ile teslim et", Durum = false },
            new TaskItem { Id = 3, GorevAdi = "Hocanın ders notlarını gözden geçir", Durum = false }
        };

        // Ana listeleme sayfasını çağıran metod
        public IActionResult Index()
        {
            // Görev listesini View tarafına aktarıyoruz
            return View(gorevListesi);
        }
    }
}