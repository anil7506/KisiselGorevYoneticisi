namespace KisiselGorevYoneticisi.Models
{
    // Görev nesnelerinin veri yapısını tutan model sınıfı
    public class TaskItem
    {
        // Görevin benzersiz id numarası
        public int Id { get; set; }

        // Görevin başlığı veya tanımı
        public string GorevAdi { get; set; }

        // Görevin tamamlanma durumu
        public bool Durum { get; set; }
    }
}